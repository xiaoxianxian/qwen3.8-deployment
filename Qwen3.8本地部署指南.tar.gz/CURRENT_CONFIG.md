# 本地 Qwen3.8-27B 部署配置快照

## 模型信息
- **名称**: qwen3.8-local:latest
- **量化**: Q5_K_M
- **大小**: 18 GB
- **上下文**: 262144 tokens（实际使用 65536）
- **能力**: vision / tools / thinking

## 文件位置
- 主模型: ~/models/qwen3.8-27b-Q5.gguf (18 GB)
- 视觉投影: ~/models/mmproj-F16.gguf (885 MB)
- 配置文件: ~/models/Modelfile

## Ollama 配置
```
FROM /Users/xiaota/.ollama/models/blobs/sha256-a83a4b635449f3d6b0feedba6087894f0282d597d868c8bdae83880b98e472cf
PROJECTOR /Users/xiaota/.ollama/models/blobs/sha256-cbb841a9ee0636b2ec172f5bb8df2ea8dfeb01e90fe7c6126581d662a0b4e43e
PARAMETER num_ctx 65536
```

## 重建方法
如需重建模型（例如源文件丢失后）：
```bash
ollama rm qwen3.8-local
ollama create qwen3.8-local -f ~/models/Modelfile
```

## 实测性能
- 生成速度: ~9.6 tok/s
- 首次加载: ~6s
- 内存占用: ~22 GB（含系统 + 上下文）

## Hermes Agent 配置
```yaml
providers:
  ollama:
    name: Ollama (Local)
    base_url: http://localhost:11434/v1
    model: qwen3.8-local:latest
    discover_models: true
```

## 切换模型命令
```
# 切换到本地模型
/model ollama/qwen3.8-local:latest

# 切换回云端模型
/model custom/agnes-2.5-flash
```
