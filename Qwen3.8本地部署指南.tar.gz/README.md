# 本地部署 Qwen3.8-27B 指南

基于 M5 Pro / 48GB 实测的本地 LLM 部署完整方案。

## 📦 GitHub 仓库内容说明

**本仓库只包含部署相关文件，不包含：**
- ❌ 开发记录（CHANGELOG.md）
- ❌ 开发想法（IDEA.md）
- ❌ 备份文件（Modelfile.*.bak-* 等）
- ❌ 调试脚本（docs/, scripts/）
- ❌ 内部测试文档（调优与避坑指南.md）

**用户可以获取的内容：**
- ✅ 完整部署方案（setup-guide.md）
- ✅ 配置参考（CURRENT_CONFIG.md）
- ✅ Ollama模型配置模板（Modelfile）
- ✅ 一键验证脚本（verify-ollama.sh）
- ✅ 部署包下载（Qwen3.8本地部署指南.tar.gz）
- ✅ 公众号文章（了解完整方案）

## 🚀 快速开始

### 1. 环境检查

```bash
# 查看内存
sysctl hw.memsize | awk '{printf "内存: %.0f GB\n", $2/1024/1024/1024}'

# 检测代理
for port in 7890 7897 1087 1080; do
  curl -s -x http://127.0.0.1:$port -o /dev/null -w "%{http_code}" https://huggingface.co | grep -q 200 && echo "代理端口: $port" && break
done
```

### 2. 选择量化版本

| 内存 | 推荐版本 | 文件大小 |
|------|---------|---------|
| 16GB | Q3_K_XL / Q4_K_M | 12-16 GB |
| 24GB+ | **Q5_K_M** ⭐ | 18.41 GB |
| 36GB+ | Q6_K_XL | 23.56 GB |
| 48GB+ | Q8_K_XL | 29.30 GB |

### 3. 验证状态

```bash
./verify-ollama.sh
```

## 📁 文件说明

```
├── README.md                        # 本文件（项目说明）
├── setup-guide.md                   # ⭐ 完整部署指南（从零开始看这个）
├── CURRENT_CONFIG.md                # 本机配置快照（参数速查）
├── Modelfile                        # Ollama 模型配置模板
├── verify-ollama.sh                 # 一键验证脚本
├── Qwen3.8本地部署指南.tar.gz       # 📦 部署包（解压即用）
├── README-资源包说明.md             # 部署包使用说明
├── 公众号文章-本地部署Qwen3.8.md    # 文章 Markdown 源文件
└── 公众号文章-本地部署Qwen3.8.html  # 文章 HTML 版本（可直接复制发布）
```

## 📊 实测性能（M5 Pro / 48GB）

### MLX 原生版（qwen3.8:27b-mlx，当前推荐）
- 生成速度：**~40 tok/s**（代码生成 40.8 / 开放式写作 29.0 / 列表结构化 34.2）
- 首 token 延迟：**3-4 秒**
- 内存占用：~18GB（nvfp4 量化）
- 自动开启 MTP 投机解码，接受率约 0.90

### GGUF 备选方案（Q5_K_M + draft_num_predict=3）
- 生成速度：~22 tok/s（代码类）
- 首次加载：~5s（常驻期间 ~0）
- 内存占用：~28GB（num_ctx=131072 时）
- 图片理解（1024px 单图 + 思考）：~17s

> MLX 原生版比 GGUF 方案快约 2 倍，且首 token 延迟更低。

## 🌐 国内镜像

如果 HuggingFace 下载慢，可以使用国内镜像：

```bash
# 方案A：hf-mirror.com
export HF_ENDPOINT=https://hf-mirror.com
ollama pull unsloth/Qwen3.8-27B-GGUF:Qwen3.8-27B-UD-Q5_K_M

# 方案B：ModelScope（魔搭社区）
pip install modelscope
python -c "from modelscope import snapshot_download; snapshot_download('Qwen/Qwen3.8-27B', cache_dir='./models')"
```

## 📝 分享给别人

- **从零部署**：发 `setup-guide.md`
- **直接下载包**：发 `Qwen3.8本地部署指南.tar.gz`
- **了解方案**：发 `公众号文章-本地部署Qwen3.8.html`

### 分享前请替换

文档里的 `<你的用户名>` 是路径占位符，对方需替换为自己的实际路径。

## 🔗 资源

- 模型仓库：https://huggingface.co/unsloth/Qwen3.8-27B-GGUF
- Ollama 文档：https://ollama.com/docs
- GitHub 仓库：https://github.com/xiaoxianxian/qwen3.8-local-deployment
