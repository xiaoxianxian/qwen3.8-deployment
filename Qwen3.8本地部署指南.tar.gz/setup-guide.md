# Qwen3.8-27B 本地部署指南（完整版）

## 概述
本文档介绍如何在本地部署 Qwen3.8-27B 多模态模型，配合 AI Agent 工具（如 Hermes Agent、WorkBuddy 等）使用。

---

## 一、前置条件

### 硬件要求
| 配置 | 最低要求 | 推荐配置 |
|------|---------|---------|
| 内存 | 32 GB | 48 GB+ |
| 磁盘 | 30 GB 可用空间 | 50 GB+ |
| GPU | 集成显卡可运行 | Apple Silicon (M系列) 性能最佳 |

### 软件要求
- macOS 13+ 或 Linux
- Ollama ≥ 0.32.0（支持多模态）
- Homebrew（macOS）

---

## 二、安装 Ollama

```bash
# macOS
brew install ollama

# 启动 Ollama 服务
ollama serve
```

新开一个终端窗口进行测试：

```bash
ollama run qwen3.8:7b "你好"
```

---

## 三、下载模型文件

### 3.1 创建模型目录
```bash
mkdir -p ~/models
cd ~/models
```

### 3.2 下载主模型（Q5_K_M 量化，约 18GB）
```bash
# 从 HuggingFace 下载（正确地址）
# 地址：https://huggingface.co/unsloth/Qwen3.8-27B-GGUF
wget https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/resolve/main/Qwen3.8-27B-UD-Q5_K_M.gguf -O qwen3.8-27b-Q5.gguf
```

### 3.3 下载视觉投影器（约 885MB）
```bash
wget https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/resolve/main/mmproj-F16.gguf -O mmproj-F16.gguf
```

> 💡 如果下载速度慢，可以使用镜像站或手动下载到本地后上传。

---

## 四、创建自定义模型

### 4.1 创建 Modelfile
在 `~/models/` 目录下创建文件 `Modelfile`（无后缀）：

```dockerfile
FROM /Users/xiaota/models/qwen3.8-27b-Q5.gguf
PROJECTOR /Users/xiaota/models/mmproj-F16.gguf
PARAMETER num_ctx 65536
```

**重要提示：**
- 将路径替换为你的实际路径
- 使用绝对路径，不要用相对路径
- `num_ctx` 可根据内存调整：22GB 内存用 32768，48GB 内存用 65536

### 4.2 创建模型
```bash
ollama create qwen3.8-local -f ~/models/Modelfile
```

---

## 五、验证部署

### 5.1 检查模型列表
```bash
ollama list
```
应该看到 `qwen3.8-local:latest`。

### 5.2 测试文本对话
```bash
ollama run qwen3.8-local "你好，请用一句话介绍你自己"
```

### 5.3 测试图片理解
```bash
ollama run qwen3.8-local "这张图里有什么？" --image /path/to/your/image.jpg
```

### 5.4 运行验证脚本
```bash
bash ~/Documents/AI项目/本地部署Qwen3.8/verify-ollama.sh
```

---

## 六、配置 AI Agent 工具

### 6.1 编辑配置文件
编辑你的配置文件（通常是 `~/.hermes/config.yaml` 或工具对应的 config 文件），在 `providers:` 下添加：

```yaml
providers:
  # 原有的云端 provider 保持不变
  custom:
    name: Custom
    base_url: https://apihub.agnes-ai.cn/v1
    model: agnes-2.5-flash
    discover_models: true
  
  # 新增 Ollama 本地 provider
  ollama:
    name: Ollama (Local)
    base_url: http://localhost:11434/v1
    model: qwen3.8-local:latest
    discover_models: true
```

### 6.2 切换模型
在你的 AI Agent 工具中使用命令切换：

```
# 切换到本地模型
/model ollama/qwen3.8-local:latest

# 切换回云端模型（如 DeepSeek）
/model 你的云端provider/deepseek-v4-pro
```

---

## 七、性能数据参考

### M5 Pro + 48GB 实测
| 指标 | 数值 |
|------|------|
| 生成速度 | ~9.6 tok/s |
| 首次响应延迟 | ~6 秒 |
| 内存占用 | ~22 GB |
| 上下文窗口 | 65536 tokens |

### 不同量化级别对比
| 量化 | 大小 | 内存需求 | 质量 | 推荐场景 |
|------|------|---------|------|---------|
| Q2_XXS | ~8GB | 10GB+ | 较差 | 仅测试用 |
| Q3_K_XL | ~12GB | 16GB+ | 中等 | 内存紧张 |
| **Q5_K_M** | **18GB** | **22GB+** | **良好** | **推荐起步** |
| Q6_K_XL | ~22GB | 28GB+ | 优秀 | 48GB内存首选 |
| Q8_K_XL | ~30GB | 40GB+ | 顶级 | 追求极致 |

---

## 八、常见问题

### Q1: 模型加载失败，提示 "no projector found"
**原因：** Modelfile 中没有 PROJECTOR 行，或者路径错误。
**解决：** 确认 Modelfile 中包含正确的 PROJECTOR 路径。

### Q2: AI Agent 工具提示 "no models advertised"
**原因：** Ollama 服务未启动，或者 base_url 配置错误。
**解决：** 
1. 确认 `ollama serve` 正在运行
2. 检查 `base_url` 是否为 `http://localhost:11434/v1`

### Q3: 上下文溢出 "context length exceeded"
**原因：** 对话历史过长，超出 `num_ctx` 限制。
**解决：** 
1. 清理对话历史
2. 或者增加 `num_ctx`（需要更多内存）

### Q4: 图片识别失败
**原因：** 模型不支持多模态，或图片格式问题。
**解决：** 
1. 确认使用的是自定义多模态模型（qwen3.8-local）
2. 尝试 JPEG/PNG 格式图片

### Q5: 内存不足导致系统卡顿
**原因：** 27B 模型占用内存较大。
**解决：** 
1. 关闭其他占用内存的应用
2. 降低 `num_ctx` 到 32768
3. 考虑使用 Q6_K_XL 量化（如果内存够）

---

## 九、配置快照备份

建议定期备份以下文件，方便重装或迁移：

```bash
# 备份模型配置
cp ~/models/Modelfile ~/models/Modelfile.backup
cp ~/models/CURRENT_CONFIG.md ~/models/CURRENT_CONFIG.md.backup

# 导出模型列表
ollama list > ~/models/model_list.txt

# 创建完整备份（可选）
tar -czf ~/models/qwen3.8-backup-$(date +%Y%m%d).tar.gz \
  ~/models/Modelfile \
  ~/models/CURRENT_CONFIG.md \
  ~/models/verify-ollama.sh
```

---

## 十、快速恢复

如果模型丢失或需要重建：

```bash
# 1. 删除旧模型
ollama rm qwen3.8-local

# 2. 重建模型
ollama create qwen3.8-local -f ~/models/Modelfile

# 3. 验证
bash ~/models/verify-ollama.sh
```

---

**祝你部署顺利！** 🚀

如有问题，欢迎在评论区留言。
